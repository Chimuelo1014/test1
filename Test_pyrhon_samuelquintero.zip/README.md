# Manejo de inventario (Python)

## 📌 Descripción
Un sistema de gestión de estudiantes universitarios construido en Python usando diccionarios,tuplas y listas. Con posibilidad de  añadir, actualizar, eliminar y buscar productos, ademas de calcular el total del inventario.

## ✅ Caracteristicas
-Agregar un nuevo producto (valida nombre, precio y unidades)

-Buscar producto por nombre (búsqueda parcial)

-Actualizar el precio  y/o las unidades del producto.

-Borrar producto por nombre(seguidamente de imprimir los productos in unidades).

-Calcular el total del inventario.

-Menú interactivo.

## 🛠 Requisitos:
Python 3.x instalado en su sistema
Recomendacion: VisualStudioCode

## 🚀 Como ejecutar :

Bienvenido a la guía de uso del programa de manejo de inventario.
En el siguiente instructivo se infiere que ya se tienen los elementos necesarios para ejecutarse tales como Python y VisualStudioCode en su defecto.
Aun así se comparte un link de un tutorial para realizarlo.

https://youtu.be/bqZP1r9V1oQ?si=AdhSPJfoB6mND1lD

Después de que tenemos todo configurado no dirigimos a visual studioCdode y abrimos el archivo descargado .py en este caso.


Dentro de VisualStudioCode y con nuestro archivo abierto, procedemos a crear una nueva terminal y escribimos Python3 seguido del nombre de nuestro archivo .py.

ahora dentro del programa se nos preguntara si queremos ingresar productos iniciales, esperando una respuesta literal de Y(si) o N(no)

![imagen](https://github.com/user-attachments/assets/79bae524-6904-4a5c-aa16-5fab0c5338eb)


si se imprime "Y" se nos pedirá la cantidad de productos iniciales que añadiremos
![imagen](https://github.com/user-attachments/assets/ec280bab-327b-4bdc-890c-df1874ae4943)

y después la información de cada producto como nombre, esperando una respuesta alfanumérica, el precio, esperando una respuesta de un numero real, y la cantidad de unidades disponibles del producto, esperando como respuesta un dígito entero

![imagen](https://github.com/user-attachments/assets/6eda8540-15c5-4e8e-8050-3b6556b0da51)

y se repite el proceso el numero de producto que digimos que ibamos a ingresar. Y despues de terminar de ingresar los productos se imprimira el menu


Si se imprime "N", se imprime directamente el menú principal con sus 6 respectivas opciones
Esperando como respuesta un numero entero según la opción que queremos realizar. 1 para añadir un producto, 2 para consultar un producto,3 para actualizar un producto, 4 para eliminar un producto, 5 para calcular el total del inventario y 6 para salir del programa, la cual es la manera correcta de salir de este.

![imagen](https://github.com/user-attachments/assets/c72b79d3-2c4c-47de-b405-59569f9d3773)



1 Agregar producto:
Primero se pide el nombre del producto esperando como respuesta una entrada alfanumérica, luego se pide el precio esperando como entrada un numero real, y por ultimo las unidades disponibles, esperando como entrada un numero entero, cada una de estas opciones con sus respectivas validaciones.
Y por ultimo se confirma si el producto ya estaba o no en el inventario.

![imagen](https://github.com/user-attachments/assets/d705f674-8d1e-422b-a31c-1f03bf8c509e)




Y despues se regresa al menu principal
 
2 Consultar productos: 

Al ingresar 2 (Consultar producto) primero se nos pedira el nombre del producto que queremos buscar, debes ingresar el nombre del producto exacto o hacer una busqueda parcial, y se imprimira en la terminal los resultados, con su nombre, precio y unidades, como en la siguiente imagen:


![imagen](https://github.com/user-attachments/assets/8943bb2f-844f-4a20-bd8f-0e3a97f6c0c3)


3 Actualizar precios y/o unidades:
Al ingresar 3(Actualizar precios y/o unidades:) se nos va a pedir el nombre del producto al cual queremos actualizar sus valores, ten en cuenta que el producto ya debe estar en el inventario.

![imagen](https://github.com/user-attachments/assets/01c7eba9-92be-48bd-ad6a-07d3ad413a0b)


luego se nos pide si queremos cambiar tambien las unidades disponibles del producto, aqui debemos ingrear "Y" si queremos cambiar tambien las unidades, y luego se nos pedira el nuevo precio del producto 

![imagen](https://github.com/user-attachments/assets/f764578d-cb11-46ac-a9d2-76b8d4800f68)


o "N" para solo cambiar el precio del producto, y se nos pedira el nuevo precio del producto

![imagen](https://github.com/user-attachments/assets/612ca82f-5fee-4b26-877f-4d30e887a31a)



4 Eliminar producto: 
Al ingresar 4(Eliminar producto), se va a imprimir una lista de los productos que no tienen unidades disponibles

![imagen](https://github.com/user-attachments/assets/36ce4c75-cf91-4fdb-80a0-59133c541a73)

y se nos pedira  el nombre del producto que queremos eliminar, ten en cuenta que el producto debe estar en el inventario, y se eliminara el producto si pasa las validaciones.

![imagen](https://github.com/user-attachments/assets/7db13ce6-cfca-474b-bbdb-0f1f9cb98d52)



5 Total del inventario:
Al ingresar 5 (Total inventario), se imprimira el precio total de todos los productos teniendo en cuenta la cantidad de unidades que tiene


![imagen](https://github.com/user-attachments/assets/de9c104a-5286-455a-9018-8727d9652655)


6. (Salir), si queremos salir del programa solo escribimos 6 en el menu.

![imagen](https://github.com/user-attachments/assets/fe1bb893-dd5c-492e-a072-3f743b390652)



# Casos de mal uso:


Estos son algunos de los ejemplos del mal uso del inventario

1 se ingresa un dato diferente al requerido
ejemplo en el menu

![imagen](https://github.com/user-attachments/assets/c26ee20a-ab22-4043-901f-4447d74ff1c1)

2 Se quiere añadir un producto que ya esta en el inventario


![imagen](https://github.com/user-attachments/assets/c0ecc661-0186-4502-9600-446f6d00571e)

3 Se consulta un producto que no esta en el inventario

![imagen](https://github.com/user-attachments/assets/0b1fccdb-139d-4913-bd13-ea29c03fcae3)



4 Se ingresa un precio de 0 o menor a 0

![imagen](https://github.com/user-attachments/assets/dcca3060-e709-4805-b7ab-323a4c7cfd5e)



![imagen](https://github.com/user-attachments/assets/74707148-d9b3-4cdc-bc13-ce523f5429d2)

5 Se quiere eliminar un producto que no esta en el inventario

![imagen](https://github.com/user-attachments/assets/481be84b-4885-49f4-b4b8-460f0f14de4b)






























